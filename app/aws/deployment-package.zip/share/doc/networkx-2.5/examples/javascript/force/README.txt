Modified from the example at of D3
http://mbostock.github.com/d3/ex/force.html

Run the file force.py to generate the force.json data file needed for this to work.

Then copy all of the files in this directory to a webserver and load force.html.

