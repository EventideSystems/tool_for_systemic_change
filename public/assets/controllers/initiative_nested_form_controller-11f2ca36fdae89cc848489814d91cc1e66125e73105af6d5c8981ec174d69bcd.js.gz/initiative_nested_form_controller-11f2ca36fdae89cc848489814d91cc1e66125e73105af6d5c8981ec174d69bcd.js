// import NestedForm from "stimulus-rails-nested-form"
// export default class extends NestedForm {
//   static values = { newItem: Object }

//   newItemValueChanged() {
//     var newItem =  this.newItemValue

//     const content = this.templateTarget.innerHTML.replace(/NEW_RECORD/g, new Date().getTime().toString())
//     this.targetTarget.insertAdjacentHTML('beforebegin', content)

//     const newSelect = $(this.targetTarget).parent().find('select').last()

//     newSelect.append(
//       $('<option>', { value: newItem.id, text: newItem.name })
//     );

//     newSelect.val(newItem.id);
//   }

// };
