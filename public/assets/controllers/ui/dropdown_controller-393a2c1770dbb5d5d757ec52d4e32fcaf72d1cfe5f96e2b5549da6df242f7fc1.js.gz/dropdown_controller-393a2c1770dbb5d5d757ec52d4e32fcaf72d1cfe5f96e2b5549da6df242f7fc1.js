// Inspired By: https://github.com/stimulus-components/stimulus-dropdown/blob/master/src/index.ts
import UIPopover from "controllers/ui/popover_controller";
import { useTransition } from "https://ga.jspm.io/npm:stimulus-use@0.51.3/dist/index.js";

export default class extends UIPopover {};
